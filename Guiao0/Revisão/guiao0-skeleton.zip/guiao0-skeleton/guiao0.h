void fill(int *vector, int size, int value);

int find(int *vector, int size, int value);
