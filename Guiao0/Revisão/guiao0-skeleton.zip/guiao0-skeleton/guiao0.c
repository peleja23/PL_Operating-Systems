#include "guiao0.h"

void fill(int *vector, int size, int value)
{
    // TODO
}

int find(int *vector, int size, int value)
{
    // TODO

    return -1;
}
