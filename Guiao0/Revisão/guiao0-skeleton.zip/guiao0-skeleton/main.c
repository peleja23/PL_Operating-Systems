#include <stdlib.h>
#include <stdio.h>
#include "guiao0.h"

int main(int argc, char const *argv[])
{
    // TODO: Initialize vector, call "fill" and "find" functions.

    return 0;
}
